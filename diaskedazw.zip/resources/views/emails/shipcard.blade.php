<html>
    <head>
    </head>
    <body>
        <h2>Package Info</h2>
        <div> Package Name: <p> {{ $messages['packagename'] }} </p></div>
        <div> Package Description: <p> {{ $messages['packagedescription'] }} </p></div>
        <div> Package Payment Description: <p> {{ $messages['packagepaymentdescription'] }} </p></div>
        <div> Package Cost: <p> {{ $messages['packagecost'] }} </p></div>
        </br>
        <h2>User Info</h2>
        <div> UserEmail: <p> {{ $messages['useremail'] }} </p></div>
        <div> UserName: <p> {{ $messages['username'] }} </p></div>
        
        <h2>Ship Card Info</h2>
        <div> First Name: <p> {{ $messages['firstname'] }} </p></div>
        <div> Last Name: <p> {{ $messages['lastname'] }} </p></div>
        <div> Address: <p> {{ $messages['address'] }} </p></div>
        <div> City: <p> {{ $messages['city'] }} </p></div>
        <div> P.O.: <p> {{ $messages['po'] }} </p></div>
        <div> Country: <p> {{ $messages['country'] }} </p></div>
        <div> telephone: <p> {{ $messages['telephone'] }} </p></div>
        <div> Mobile: <p> {{ $messages['mobile'] }} </p></div>
        <div> Email: <p> {{ $messages['email'] }} </p></div>
        <div> Message: <p> {{ $messages['message'] }} </p></div>
    </body>
</html>