<html>
    <head>
    </head>
    <body>
    
        <div>Name: <p>{{ $messages['name'] }}</p></div>
        <div>Surname: <p>{{ $messages['surname'] }}</p></div>
        <div>Email: <p>{{ $messages['email'] }}</p></div>
        <div>Reference: <p>{{ $messages['reference'] }}</p></div>
    </body>
</html>