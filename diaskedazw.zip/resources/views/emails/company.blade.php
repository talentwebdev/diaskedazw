<html>
    <head>
    </head>
    <body>
        <div> Company: <p> {{ $messages['company'] }} </p></div>
        <div> Type: <p> {{ $messages['type'] }} </p></div>
        <div> Email: <p> {{ $messages['email'] }} </p></div>
    </body>
</html>