<html>
    <head>
    </head>
    <body>
        <div> First Name: <p> {{ $messages['firstname'] }} </p></div>
        <div> Last Name: <p> {{ $messages['lastname'] }} </p></div>
        <div> Address: <p> {{ $messages['address'] }} </p></div>
        <div> City: <p> {{ $messages['city'] }} </p></div>
        <div> P.O.: <p> {{ $messages['po'] }} </p></div>
        <div> Country: <p> {{ $messages['country'] }} </p></div>
        <div> telephone: <p> {{ $messages['telephone'] }} </p></div>
        <div> Mobile: <p> {{ $messages['mobile'] }} </p></div>
        <div> Email: <p> {{ $messages['email'] }} </p></div>
        <div> Message: <p> {{ $messages['message'] }} </p></div>
    </body>
</html>