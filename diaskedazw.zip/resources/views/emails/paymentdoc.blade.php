<html>
    <head>
    </head>
    <body>
    
        <h2>Package Info</h2>
        <div> Package Name: <p> {{ $messages['packagename'] }} </p></div>
        <div> Package Description: <p> {{ $messages['packagedescription'] }} </p></div>
        <div> Package Payment Description: <p> {{ $messages['packagepaymentdescription'] }} </p></div>
        <div> Package Cost: <p> {{ $messages['packagecost'] }} </p></div>
        
        </br>
        <h2>User Info</h2>
        <div> UserEmail: <p> {{ $messages['useremail'] }} </p></div>
        <div> UserName: <p> {{ $messages['username'] }} </p></div>

        <h2>Paymetn Detailed Info Document </h2>
    </body>
</html>