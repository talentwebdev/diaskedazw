<div class='row' id='latest-articles'>
</div>

@push('scripts')
<script> const article_cnt = parseInt("{{ $count }}"); </script>
<script src="{{ asset('js/user-pages/partnerprofile/article.js') }}"></script>
@endpush