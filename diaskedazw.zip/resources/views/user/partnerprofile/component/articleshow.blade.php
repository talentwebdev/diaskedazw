<div class='article-show-section'>
    <h4 class='article-show-title'></h4>
    <p class='article-show-content'></p>

    <div class='article-show-like' style='display:none;'>
        <div class='like-button-container' article-id='' style='margin:auto;'>
            <a style='padding: 5px;'><i article-id='' class='fas fa-star '></i> <span class='count'><span></a>
            <a style='padding: 5px;'><i article-id='' class='fas fa-sign-language '></i> <span class='count'><span></a>
            <a style='padding: 5px;'><i article-id='' class='fas fa-heart '></i> <span class='count'><span></a>
        </div>
    </div>
</div>

@push('scripts')
<script src="{{ asset('js/user-pages/partnerprofile/articleshow.js') }}"></script>
@endpush