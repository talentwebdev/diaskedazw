<div class='row product-container' id='companies-container'>
    
</div>
@push('scripts')
<script src="{{ asset('js/user-pages/product/product.js') }}"></script>
@endpush

@push('styles')
<link type='text/css' href='{{ asset("css/loading/style.css") }}' rel='stylesheet'>
@endpush