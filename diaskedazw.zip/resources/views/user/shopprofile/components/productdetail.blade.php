<div class="container product-detail" style="display:none;">
    <div class="row ">
        <div class="col-md-4">
            <div class="main-product-image tile" data-scale="2.4" >
                <img src="" class='photo' width='100%' />
            </div>
            <div class="sub-product-image-container" style="display:flex;">
                
            </div>
        </div>
        <div class="col-md-8">
            <div class="product-info">
                <div class="product-title">
                Relojes 2018 Watch Men LIGE Fashion Sport Quartz Clock Mens Watches Top Brand Luxury Business Waterproof Watch Relogio Masculino
                </div>
                <div class="product-price">
                    <h4></h4>
                </div>
                <div class="product-color">
                    <label>Χρώμα:</label>
                    <div class="product-color-images" style="display:flex;">
                        
                    </div>
                </div>
                <div >
                    <label>Μέγεθος:</label>
                    <div class="product-size-container" style="display:flex;">
                        <div class="size-container">XL</div>
                    </div>
                </div>
                <div>
                    <label>Περιγραφή:</label>
                    <div class="product-description">
                    </div>
                </div>
                
                <div class="product-button" style="display: flex; display: row;">
                    <button class="btn btn-primary" id="buyBtn">Αγορά</button>
                    <button class="btn btn-primary" id="backBtn">Πίσω</button>
                </div>
            </div>
        </div>
    </div>
    <div class="row product-overviews">
    </div>
</div>
@push("scripts")
<script src="{{ asset('js/user-pages/shopprofile/detail.js') }}"></script>
@endpush