
    <canvas id="animationMap" style='position:fixed; top: 0px; z-index: -1;'></canvas>    

@push('scripts')

@endpush

