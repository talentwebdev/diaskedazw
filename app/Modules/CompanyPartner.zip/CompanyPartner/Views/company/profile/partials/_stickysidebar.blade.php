
<div class='sticky-sidebar-container'>
    <div class='sticky-sidebar' style='width: 100%;'>
        <div class='menu'>
            <h4> Μενού </h4>
            <div id='home-menu'> <a href='{{ route("company.profile.index") }}'>Αρχική</a> </div>
            <div id='video-menu'> <a href='{{ route("company.profile.video") }}'>Videos</a> </div>
            <div id='article-menu'> <a href='{{ route("company.profile.article") }}'>Άρθρα</a> </div>
            <div id='gallery-menu'> <a href='{{ route("company.profile.image") }}'>Εικόνες</a> </div>        
            <div id='gallery-menu'> <a href='' user-id="{{ $partner->id }}" id='eshop-link'>Eshop</a> </div>        
            <div id='website-menu'> <a href='{{ $company->link_url }}'>Website</a> </div>        

            @if($has_product == 1)
            <form id="myform" role="form"  method="get" action="{{URL::to('product')}}">
                <input type = "hidden" value="{{$partner->id}}" name="user_id" />            
                <div id='website-menu'> <a href='#' onclick="document.getElementById('myform').submit()">Product</a> </div>        
            </form>
            @endif
                                
        </div>
        <div>
            <img src="" />
        </div>
        <div style="display: flex;">
            <h5> Current Visit Users: </h5> &nbsp;
            @auth
            <h5 id="current-visit-users"></h5>
            @else
            <a id="login-link"> Login </a>
            @endauth
        </div>
    </div>
</div> 

@push("scripts")
<script src="{{ asset('plugins/sticky-sidebar/sticky-sidebar.js') }}"></script>
<script src="https://js.pusher.com/4.4/pusher.min.js"></script>
<script>
    new StickySidebar('.sticky-sidebar-container', {
        topSpacing: 80,
        containerSelector: '.mainarea'
    });

/*
    var pusher = new Pusher('b6710519609f96a78b9b');
    var presenceChannel = pusher.subscribe('presence-example');
    presenceChannel.bind('pusher:subscription_succeeded', function() {
        alert("hello");
        var me = presenceChannel.members.me;
        var userId = me.id;
        var userInfo = me.info;
    });
  */  

    Echo.join('company.' + "{{ $company->user_id }}")
        .here(users => {
            $("#current-visit-users").text(users.length);
        })
        .joining((user) => {
            var current_users = parentInt($("#current-visit-users").text());
            current_users ++;
            $("#current-visit-users").text(current_users);

            //addChatComponent(user);           
            
        })
        .leaving((user) => {
            var current_users = parentInt($("#current-visit-users").text());
            current_users --;
            $("#current-visit-users").text(current_users);
        });

    $("#login-link").click(e => {
        $("#email").focus();
    });
    
    $("#eshop-link").click(e => {
        $.post("{{ route('productprofile') }}", {_token: "{{ csrf_token() }}", user_id: $("#eshop-link").attr("user-id")})
                .done(data => {
                    location.href = "{{ route('shopprofile') }}";
                })
                .fail(err => {});
    });
</script>
@endpush

@push("styles")
<style>
@media only screen and (max-width:991px){
    #calendar{
        display: none;
    }
}
</style>
@endpush