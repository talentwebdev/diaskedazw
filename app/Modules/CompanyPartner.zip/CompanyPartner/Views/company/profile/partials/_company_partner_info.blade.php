<div class="row">
    <div class="col-md-4">
        <div class='communication-tip-container'>
            <span class='tip-box' style="color:white;">Communication</span>
            <div class='communication-info-tip'>{{ $company->communication }} </div>
        </div>
        <div>
            <i class="fas fa-map-marker-alt"></i> &nbsp; <label> {{ $partner->address }} </label>
        </div>
        <div>
            <i class="fas fa-at"></i> &nbsp; <label> {{ $company->email }} </label>
        </div>
        <div>
            <i class="fas fa-phone-volume"></i> &nbsp; <label> {{ $partner->telephone }} </label>
        </div>
        <div>
            <i class="fas fa-mobile-alt"></i> &nbsp; <label> {{ $partner->mobile }} </label>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <span class='tip-box' style="color:white;">Inbox</span>
            <form id="inbox-info-form">
                @csrf
                <input type="hidden" value="{{ $partner->id }}" name='partner_id' id='partner_id' />
                <div class="inbox-container" style="padding: 10px;">
                    <div class="row">
                        <div class="col-md-6">
                            <label> Name: </label>
                            <input type="text" name="name" id="name" class="form-control" />
                        </div>
                        <div class="col-md-6">
                            <label> Email: </label>
                            <input type="text" name="email" id="email" class="form-control" />
                        </div>
                        <div class="col-md-12">
                            <label> Message: </label>
                            <textarea rows='4' name="message" id="message" class="form-control"></textarea>
                        </div>
                        <div class="col-md-12">
                            <button class="btn btn-primary" id='submit-inbox-btn' style="float:right;"> Submit </button>
                        </div>
                    </div>   
                </div>
            </form>
        </div>
    </div>
    <div class="col-md-4">
        <div class="embed-responsive embed-responsive-16by9 z-depth-1-half" id="map">
        </div>
    </div>
</div>

@push("styles")
<style>
.inbox-container,
.communication-info-tip{
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #AAA;
}
</style>
@endpush

@push("scripts")
<script>
$(document).ready(e => {
    $("#submit-inbox-btn").click(e => {
        $.post("{{ route('company.inbox.store') }}", $("#inbox-info-form").serializeToJSON())
            .done(data => {
                $("#name").val("");
                $("#email").val("");
                $("#message").val("");
            })
            .fail(err => {

            });    
        e.preventDefault();
        return false;    
    });

    function dealWithMapbox()
    {
        var map = $("#map").my_own_mapbox(
        {
            token: "pk.eyJ1IjoiZGlhc2tlZGF6dyIsImEiOiJjazA1Z2t3eWczZmJrM251dDRwaWkxNGkyIn0.5WkL6xzwa8b65Z6FFmEpRQ",
            onComplete: function(){
            },
            starting_query: "{{ $company->address ?? "Cyprus" }}"
        }
        );
    }
    
    dealWithMapbox();
});
</script>
@endpush