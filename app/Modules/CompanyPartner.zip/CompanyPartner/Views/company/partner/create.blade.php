@extends("layouts.app")

@section('content')

<div class="container">
    <div class="card">
        <div class="card-header">
            <h4> Become a Company Partner </h4>
        </div>
        <div class="card-body">
            @foreach($errors->all() as $message)
                <div class="error-message" >
                    {{ $message }}
                </div>
            @endforeach
            <form action="{{ route('company.partner.companycreate') }}" method="post" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="address" value="{{ old('address') }}" />
                <div class="row">
                    <div class="col-md-12">
                        <h5> Company Name: </h5>
                        <input type="text" class="form-control" value='{{ old('company_name') }}' name="company_name" id='companyName' />
                    </div>
                    <div class="col-md-12">
                        <h5> Company Logo: </h5>
                        <input type="file" name="company_logo" id="companyLogoFile" />
                        <img src="" id="logoPreview" width='80' height='80' />
                    </div>
                    <div class="col-md-12">
                        <h5> Company Video: </h5>
                        <!-- upload user eshop promote video part -->
                        <div>
                            <div id='preview-video-container'>
                                <video id="preview-video" loop="loop" width="100%" height='100%' controls>
                                    <source src="" type="video/mp4">
                                </video>
                            </div>  
                            <div class="upload-drop-zone" id="drop-zone">            
                                <div class="form-group">
                                    <h2> <i class="fas fa-upload" style='color: rgb(0, 173, 239); font-size:50px;'></i> </h2> 
                                    <h4> Drag and drop anywhere to upload </h4> 
                                    <input type="file" name="video" id="video" class="inputfile inputfile-1" data-multiple-caption="{count} files selected" multiple="">
                                    <label for="video"><svg xmlns="#" width="20"  viewBox="0 0 20 17">
                                        <path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path>
                                        </svg> <span>Choose a file…</span></label>
                                </div>                      
                            </div>
                            <div class="progress" style='height:1px;'>
                                <div class="progress-bar" role="progressbar" id='video-progress' style="height:100%;" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <!-- upload user eshop promote video part end -->
                        <input type="text" style="display: none;" name="company_video" />
                    </div>
                    <div class="col-md-12">
                        <h5> Link url: </h5>
                        <input type="text" class="form-control" value="{{ old('link_url') }}" name="link_url" />
                    </div>



                    <div class="col-md-12">
                        <h5> Area: </h5>
     
                        <div class="wrapper-dropdown-3" style="border:none !important;">
                            <select class="js-example-basic-single" style="width:100%; " id="company_area" name="company_area[]" multiple="multiple">
                                <option > </option>                                                                                    
                            </select>
                        </div>
                                            
                    </div>
                    

                        
                    <!-- <div class="col-md-12">
                        <h5> Area: </h5>

                        <div id="areaDropdown" class="wrapper-dropdown-3">
                            <span>Select Area...</span>
                            <ul class="dropdown" id='areaList'>						
                            </ul>
                        </div>
                        <input type="text" value="{{ old('company_area') }}" name="company_area" style="display:none;" />

                    </div> -->

                    <!-- <div class="col-md-12">
                        <h5> Category: </h5>
                        <div id="categoryDropdown" class="wrapper-dropdown-3">
                            <span>Select Category...</span>
                            <ul class="dropdown" id='categoryList'>						
                            </ul>
                        </div>
                        <input type="text" value="{{ old('company_category') }}" name="company_category" style="display: none;" />
                    </div> -->

                    <div class="col-md-12">
                        <h5> Area: </h5>
     
                        <div class="wrapper-dropdown-3" style="border:none !important;">
                            <select class="js-example-basic-single2" style="width:100%; " id="company_category" name="company_category[]" multiple="multiple">
                                <option > </option>                                                                                    
                            </select>
                        </div>
                                            
                    </div>


                    <div class="col-md-12">
                        <h5> Company Email: </h5>
                        <input type="email" class="form-control" value="{{ old('email')}}"  name="email" required/>
                    </div>

                    <div class="col-md-12">
                        <h5> Discount Count: </h5>
                        <input type="number" class="form-control" value="{{ old('discount_cnt')}}"  name="discount_cnt" />
                    </div>
                    <div class="col-md-12">
                        <h5> Discount Info: </h5>
                        <textarea class="form-control" rows='3' value='{{ old('discount_info') }}'  name="discount_info">{{ old('discount_info') }}</textarea>
                    </div>
                    <div class="col-md-12">
                        <h5> Description: </h5>
                        <textarea class="form-control" rows='4' value='{{ old('company_description')}}' name="company_description">{{ old('discount_info') }}</textarea>
                    </div>
                    <div class="col-md-12">
                        <h5> Company Communication: </h5>
                        <textarea class="form-control" rows='2' value='{{ old('company_communication')}}' name="company_communication">{{ old('discount_info') }}</textarea>
                    </div>
                    <div class="col-md-12">
                        <h5> Slogan: </h5>
                        <textarea class="form-control" rows='2'  value='{{ old('company_slogan')}}' name="company_slogan">{{ old('company_slogan') }}</textarea>
                    </div>
                    
                    <div class="col-md-4">
                        <h5> Facebook: </h5>
                        <input type="text" id='facebook' name='facebook' class='form-control' value="{{ old('facebook') }}" />
                    </div>
                    <div class="col-md-4">
                        <h5> Youtube: </h5>
                        <input type="text" id="youtube" name="youtube" class="form-control" value="{{ old('youtube') }}" />
                    </div>
                    <div class="col-md-4">
                        <h5> Twitter: </h5>
                        <input type="text" id="twitter" name="twitter" class="form-control" value="{{ old('twitter') }}" />
                    </div>
                    <div class="col-md-12">
                        <div class="embed-responsive embed-responsive-16by9 z-depth-1-half" id="map">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary" style="float:right;"> Save </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<form action="{{ route('uploadvideo.file') }}" method='post' enctype='multipart/form-data' id='js-upload-form'>
    @csrf
</form>
@endsection




@push("styles")
<link rel='stylesheet' href="{{ asset('plugins/select-component/select-component.css') }}" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" />
<!-- <link rel='stylesheet' href="{{ asset('plugins/select2/select2.min.css') }}" /> -->
<style>
.card{
    margin-top: 60px;
}
</style>
@endpush

@push("scripts")
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
    <script src="{{ asset('plugins/select-component/select-component.js') }}"></script>
    <!-- <script src="{{ asset('plugins/select2/select2.min.js') }}"></script> -->
    @include("company.partner.js_partials.__js_create")
    <script>
        $(document).ready(function(){            
            $(".js-example-basic-single").select2({
                placeholder:"Choose Area"
            });

            $(".js-example-basic-single2").select2({
                placeholder:"Choose Category"
            });

        });
    </script>
@endpush