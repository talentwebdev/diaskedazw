var main_services = [
    
{
        "name": "Σώμα - Μυαλό - Πνεύμα",
        "img_url": asset_url + "/" + "img/services/service_ad/1.png",
        "sub_component": [            
             {
                "name": "Γυμναστής", "img_url": asset_url + "/" + "img/services/service_it/1.1.png", 
                "sub_component": [
                    { "name": "Δημήτρης Ανδρέου", "img_url": asset_url + "/" + "img/services/service_ot/dimikips.png", "sub_component": [
                    { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/1.1.1.png", "partner":10}
                ],
                "adv_img": asset_url + "/" + "img/services/service_ot/dimikips.png",
                "description":"Τα λόγια, δεν είναι εφικτό να μοιάζουνε σαν πράξεις... Μα τα γραπτά όμως εδώ, φρόντισε να τα ψάξεις."
                }
            ],
                 "adv_img": asset_url + "/" + "img/services/1.1.1.png",
        "description":" Δημήτρης Ανδρέου"
            
                
                
            
    },

{ "name": "Διατροφολόγος", "img_url": asset_url + "/" + "img/services/service_it/1.2.png", 
    "sub_component": [
                  { "name": "Διατροφλόγος", "img_url": asset_url + "/" + "img/services/service_ad/1.2.png", "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/service_ad/1.2.png", "partner":1}
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ad/1.2.png",
        "description":"."
 }
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ad/1.2.png",
        "description":"."
},
            
            { "name": "Βοτανολόγος", "img_url": asset_url + "/" + "img/services/service_it/1.4.png", 
            "sub_component": [
                  { "name": "Νόντας Επαμηνώντας", "img_url": asset_url + "/" + "images/sinergateskipseles/nontaskips.png", "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/service_ad/1.4.png", "partner":13}
                 ],
                 "adv_img": asset_url + "/" + "images/sinergateskipseles/nontaskips.png",
        "description":"Αλλάξτε τον τρόπο που βλέπετε τα πράγματα και τα πράγματα που βλέπετε θα αρχίσουν να αλλάζουν."  ,
        "link": {
            type: 2,
            href: 13
        }

 }
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ad/1.4.png",
        "description":"Νόντας Επαμηνώντας"
         ,
        "link": {
            type: 2,
            href: 13
        }
},
            { "name": "Ψυχολογία", "img_url": asset_url + "/" + "img/services/service_it/1.5.png", 
            "sub_component": [
                  { "name": "Γεωργία Κοντογιώργη", "img_url": asset_url + "/" + "img/services/service_ad/1.5.png", "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/service_ad/1.5.png", "partner":1}
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ad/1.5.png",
        "description":" ."
 }
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ad/1.5.png",
        "description":"Γεωργία Κοντογιώργη"
},
            
              { "name": "Διαλογισμός - Yοga", "img_url": asset_url + "/" + "img/services/service_it/1.7.png", "sub_component": [
                  { "name": "Γεωργία Καλλιανή Yogeswhari", "img_url": asset_url + "/" + "img/services/service_ot/georgiakips.png", "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/service_ad/1.7.png", "partner":40}
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/georgiakips.png",
        "description":"Όλα γίνονται για κάποιο λόγο"  ,
        "link": {
            type: 2,
            href: 40
        }
 }
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ad/1.7.png","description":"Γεωργία Καλλιάνη"
    }
               ],
        "adv_img": asset_url + "/" + "img/services/service_at/Α.png",
        "description":" Γυμναστής  ,  Διατροφολόγος ,  Φυσιοθεραπευτής ,  Βοτανολόγος ,  Ψυχολογία ,  Διαλογισμός . "
    },

               
    {
        "name": "Σεμινάρια",
        "img_url": asset_url + "/" + "img/services/service_ad/2.png",
        "sub_component": [
            { "name": "Life Coaching", "img_url": asset_url + "/" + "img/services/service_it/2.1.png",
            "sub_component": [
            { "name": "Έλενα Κουππαρή", "img_url": asset_url + "/" + "images/sinergateskipseles/elenakips.png", 
             "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/2.1.png", "partner":15}
                 ],
                 "adv_img": asset_url + "/" + "images/sinergateskipseles/elenakips.png",
        "description":"H προσωπική ανάπτυξη δεν σταματά ποτέ. Είναι ένα ταξίδι που όταν το ξεκινήσεις συνειδητοποιείς πόσα πολλά έχεις ακόμα να ανακαλύψεις.Γι’ αυτό συνεχίζω την εκπαίδευση μου στον Νευρογλωσσικό Προγραμματισμό (NLP)." ,
        "link": {
            type: 2,
            href: 15
        }
},

            { "name": "Αγγελική Σάββα", "img_url": asset_url + "/" + "images/sinergateskipseles/aggelikikips.png", 
             "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/2.1.png", "partner":14}
                 ],
                 "adv_img": asset_url + "/" + "images/sinergateskipseles/aggelikikips.png",
        "description":" ." ,
        "link": {
            type: 2,
            href: 14
        }
},
            { "name": "Χριστίνα Σωκράτους", "img_url": asset_url + "/" + "img/services/service_ot/hristinakips.png", 
             "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/2.1.png", "partner":1}
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/hristinakips.png",
        "description":" ."
},
            { "name": "Λιάνα Νικολάου", "img_url": asset_url + "/" + "images/sinergateskipseles/lianakips.png",  "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/2.1.png", "partner":1}
                 ],
                 "adv_img": asset_url + "/" + "images/sinergateskipseles/lianakips.png",
        "description":"Ιδιαίτερη της χαρά ειναι να βλέπει τους πελάτες της να βρίσκουν την ευτυχία στις σχέσεις τους με τους εαυτούς τους και στις προσωπικές τους σχέσεις μέσω των ιδιωτικών συνεδριάσεων που τους παρέχει."
}
              ],
                 "adv_img": asset_url + "/" + "img/services/2.1.png",
        "description":" ."
            
                
                
            
    },
            { "name": "Internet Marketing", "img_url": asset_url + "/" + "img/services/service_it/2.2.png",  "sub_component": [
                  { "name": "Ιάκωβος Θεοδώρου", "img_url": asset_url + "/" + "img/services/2.2.png", "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/2.2.png", "partner":1}
                 ],
                 "adv_img": asset_url + "/" + "img/services/2.2.png",
        "description":"Ιάκωβος Θεοδώρου"
 }
                 ],
                 "adv_img": asset_url + "/" + "img/services/2.2.png",
        "description":"Ιάκωβος Θεοδώρου"
            
               
                
            
    },
            { "name": "Social Marketing", "img_url": asset_url + "/" + "img/services/service_it/2.3.png", "sub_component": [
                  { "name": "Κρίς Πολυκάρπου", "img_url": asset_url + "/" + "images/sinergateskipseles/chriskips.png", "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/2.3.png", "partner":10}
                 ],
                 "adv_img": asset_url + "/" + "images/sinergateskipseles/chriskips.png",
        "description":"Το Δικτυακό Μάρκετινγκ είναι η καλύτερη ευκαιρία του σήμερα και για τα επόμενα χρόνια για οικονομική ανεξαρτησία και ευημερία."  ,
        "link": {
            type: 2,
            href: 10
        }
 }
                 ],
                 "adv_img": asset_url + "/" + "img/services/2.3.png",
        "description":"+ Κρίς Πολυκάρπου" ,
        "link": {
            type: 2,
            href: 10
        }
            
                
                
            
    },
            { "name": "Επιχειρηματικά", "img_url": asset_url + "/" + "img/services/service_it/2.4.png", "sub_component": [
                  { "name": "Γιώργος Κορέλλης", "img_url": asset_url + "/" + "img/services/service_ot/korellikips.png", "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/2.4.png", "partner":1}
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/korellikips.png",
        "description":" ."
 }
                 ],
                 "adv_img": asset_url + "/" + "img/services/2.4.png",
        "description":"Γιώργος Κορέλλης"
            
                
                
            
    },
            { "name": "Branding/Social Media", "img_url": asset_url + "/" + "img/services/service_it/2.5.png", "sub_component": [
                  { "name": "Ανδιανή Τσαλαμάτη", "img_url": asset_url + "/" + "img/services/2.5.png", "sub_component": [
                  { "name": "Προφίλ", "img_url": asset_url + "/" + "img/services/2.5.png", "partner":1}
                 ],
                 "adv_img": asset_url + "/" + "img/services/2.5.png",
        "description":"."
 }
                 ],
                 "adv_img": asset_url + "/" + "img/services/2.5.png",
        "description":"."
            
                
                
            
    }
        ],
        "adv_img": asset_url + "/" + "img/services/service_at/Β.png",
        "description":"."
    },
{
        "name": "Διασκέδαση",
        "img_url": asset_url + "/" + "img/services/service_ad/3.png",
        "sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_at/Γ.png",
        "description":"."
    },

   
    {
        "name": "ECO",
        "img_url": asset_url + "/" + "img/services/service_ot/eco.png",
        "sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/ecob.png",
        "description":"Ως μέλος Diaskedazw επωφελείστε εφόρου ζωής." , "link": {
type: 1,
href: "https://diaskedazw.com/"
}
    },

    {
        "name": "Food & Coffee",
        "img_url": asset_url + "/" + "img/services/service_ot/food.png",
        "sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/Food&Coffeeb.png",
        "description":"."
    },

    
    {
        "name": "Υγεία & Ασφάλεια",
        "img_url": asset_url + "/" + "img/services/service_ot/igia.png",
        "sub_component": [
            { "name": "Επενδυτικά", "img_url": asset_url + "/" + "img/services/service_it/7.1.png","sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/7.1.png",
        "description":"."
    },
                
            
          { "name": "Συνταξιοδοτικά", "img_url": asset_url + "/" + "img/services/service_it/7.2.png","sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/7.2.png",
        "description":"."
    },
                
            
    
            { "name": "ΓεΣΥ", "img_url": asset_url + "/" + "img/services/service_it/7.3.png",
   "sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/7.3.png",
        "description":"Περισσότερες Πληροφορίες."
    },
            { "name": "Φοροαπαλλαγή", "img_url": asset_url + "/" + "img/services/service_it/7.4.png","sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/7.4.png",
        "description":"."
    },
                
            
  
            { "name": "Επιχειρηματικές Ασφαλήσεις", "img_url": asset_url + "/" + "img/services/service_it/7.5.png" ,"sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/7.5.png",
        "description":"."
                
            
    },
          { "name": "Ασφάλεια Αυτοκινήτων", "img_url": asset_url + "/" + "img/services/service_it/7.6.png" ,"sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/7.6.png",
        "description":"."
                
            
    },
    
          { "name": "Ευθύνη Εργοδότη", "img_url": asset_url + "/" + "img/services/service_it/7.7.png" ,"sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/7.7.png",
        "description":"."
                
            
    }
        ],
        "adv_img": asset_url + "/" + "img/services/service_ot/igiab.png",
        "description":"."
    },

    {
        "name": "Ενοικιαγορές Οχημάτων",
        "img_url": asset_url + "/" + "img/services/service_ad/8.png",
        "sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_at/Θ.png",
        "description":"."
    },

    {
        "name": "Future",
        "img_url": asset_url + "/" + "img/services/service_ot/future.png",
        "sub_component": [
        ],
        "adv_img": asset_url + "/" + "img/services/service_ot/futureb.png",
        "description":"."
    },

    {
        "name": "E-shop Ewallet",
        "img_url": asset_url + "/" + "img/services/service_ad/10.png",
        "sub_component": [
            
            { "name": "E-shop", "img_url": asset_url + "/" + "img/services/service_ot/10e.png", "sub_component": [  ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/eshopa.png",
         "description":"." , "link": {
type: 1,
href: "https://diaskedazwdiscounts.com/product"
}
            
            },
              { "name": "Ewallet", "img_url": asset_url + "/" + "img/services/service_ot/ewallet.png", "sub_component": [  ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/ewalleta.png",
         "description":"." , "link": {
type: 1,
href: "https://diaskedazwdiscounts.com/product"
}
              },          
                
    
         ],  
        "adv_img": asset_url + "/" + "img/services/service_ot/eshopwallet.png",
        "description":"."
    },

    {
        "name": "Τεχνολογία",
        "img_url": asset_url + "/" + "img/services/service_ot/tehnologia.png",
        "sub_component": [
            
            { "name": "Τηλεώραση", "img_url": asset_url + "/" + "img/services/service_ot/tileorasi.png", "sub_component": [  ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/tileorasia.png",
         "description":"." , "link": {
type: 1,
href: "https://diaskedazwdiscounts.com/"
}
            
            },
              { "name": "Παιχνίδια", "img_url": asset_url + "/" + "img/services/service_ot/games.png", "sub_component": [  ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/gamesa.png",
         "description":"." , "link": {
type: 1,
href: "https://diaskedazwdiscounts.com/"
}
              },          
    ],
        "adv_img": asset_url + "/" + "img/services/service_ot/tehnologiab.png",
        "description":"."
    },

    {
        "name": "Development",
        "img_url": asset_url + "/" + "img/services/service_ot/Development.png",
        "class": "push-bottom",
        "sub_component": [
            
                        
            { "name": "Ακίνητα", "img_url": asset_url + "/" + "img/services/service_ot/ΑΚΙΝΗΤΑ.png", "sub_component": [  ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/ΑΚΙΝΗΤΑa.png",
         "description":"." , "link": {
type: 1,
href: "https://diaskedazwdiscounts.com/product"
}
            
            },
                 { "name": "Αρχιτεκτονική", "img_url": asset_url + "/" + "img/services/service_ot/ΑΡΧΙΤΕΚΤΟΝΙΚΗ.png", "sub_component": [  ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/ΑΡΧΙΤΕΚΤΟΝΙΚΗa.png",
         "description":"." , "link": {
type: 1,
href: "https://diaskedazwdiscounts.com/product"
}
            
            },
            
            { "name": "Οικόπεδα", "img_url": asset_url + "/" + "img/services/service_ot/ΟΙΚΟΠΕΔΑ.png", "sub_component": [
                 ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/ΟΙΚΟΠΕΔΑa.png",
        "description":" ."
            
                
                
            
    }
          
        ],
        "adv_img": asset_url + "/" + "img/services/service_ot/Developmentb.png",
        "description":"."
    }
]