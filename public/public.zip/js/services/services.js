var main_services = [
    
{
        "name": "Mind & Seminars",
        "img_url": asset_url + "/" + "img/services/service_ot/seminar.png",
        "sub_component": [            
            
               ],
        "adv_img": asset_url + "/" + "img/services/service_ot/seminars.png",
        "description":""
    },

               
    {
        "name": "Μυαλό Ψυχή & Σώμα",
        "img_url": asset_url + "/" + "img/services/service_ot/health.png",
        "hover_img_url": asset_url + "/" + "img/services/service_ot/seminars.png",
        "sub_component": [
            
        ],
        "adv_img": asset_url + "/" + "img/services/service_ot/healths.png",
        "description":""
    },
{
        "name": "Φαγητό & Ποτό",
        "img_url": asset_url + "/" + "img/services/service_ot/food.png",
        "sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/foods.png",
        "description":""
    },

   
    {
        "name": "Διασκέδαση",
        "img_url": asset_url + "/" + "img/services/service_ot/fun.png",
        "sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/funs.png",
        "description":"" /*, "link": {
type: 1,
href: "https://diaskedazw.com/"
}*/
    },

    {
        "name": "Κινούμενα Μέσα (αυτοκίνηση)",
        "img_url": asset_url + "/" + "img/services/service_ot/car.png",
        "sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/car_s.png",
        "description":""
    },

    
    {
        "name": "Σπίτι του Μέλλοντος/Ηouse of the Future",
        "img_url": asset_url + "/" + "img/services/service_ot/house.png",
        "sub_component": [
           
        ],
        "adv_img": asset_url + "/" + "img/services/service_ot/houses.png",
        "description":""
    },

    {
        "name": "ECO Energy",
        "img_url": asset_url + "/" + "img/services/service_ot/eco-01.png",
        "sub_component": [],
        "adv_img": asset_url + "/" + "img/services/service_ot/ecos-01.png",
        "description":""
    },

    {
        "name": "Εκπτώσεις Diaskedazw & E-shop",
        "img_url": asset_url + "/" + "img/services/service_ot/newdisc.png",
        "sub_component": [
        ],
        "adv_img": asset_url + "/" + "img/services/service_ot/newdiscs.png",
        "description":""
    },

    {
        "name": "Business Support",
        "img_url": asset_url + "/" + "img/services/service_ot/buis.png",
        "sub_component": [
            
         ],  
        "adv_img": asset_url + "/" + "img/services/service_ot/buiss.png",
        "description":""
    },

    /*{
        "name": "Τεχνολογία",
        "img_url": asset_url + "/" + "img/services/service_ot/tehnologia.png",
        "sub_component": [
            
            { "name": "Τηλεώραση", "img_url": asset_url + "/" + "img/services/service_ot/tileorasi.png", "sub_component": [  ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/tileorasia.png",
         "description":"." , "link": {
type: 1,
href: "https://diaskedazwdiscounts.com/"
}
            
            },
              { "name": "Παιχνίδια", "img_url": asset_url + "/" + "img/services/service_ot/games.png", "sub_component": [  ],
                 "adv_img": asset_url + "/" + "img/services/service_ot/gamesa.png",
         "description":"." , "link": {
type: 1,
href: "https://diaskedazwdiscounts.com/"
}
              },          
    ],
        "adv_img": asset_url + "/" + "img/services/service_ot/tehnologiab.png",
        "description":"."
    },
*/
    {
        "name": "Καριέρα ΖWής",
        "img_url": asset_url + "/" + "img/services/service_ot/efkeria-01.png",
        "class": "push-bottom",
        "sub_component": [
            
            
        ],
        "adv_img": asset_url + "/" + "img/services/service_ot/ellins-01.png",
        "description":""
    }
]