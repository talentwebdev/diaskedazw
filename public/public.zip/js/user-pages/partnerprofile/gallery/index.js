
(function ($) {
    'use strict';

        // *********************************
        // :: 1.0 add Chat component
        // *********************************
        Echo.join( 'chat.' + partner.id )
                    .here((users) => {
                        console.log("Join Channel() success", users);
                    });
        // *********************************
        // :: 2.0 add Chat component
        // *********************************
        $("#gallery-menu").addClass('active');

        // *********************************
        // :: 3.0 set mall top menu
        // *********************************
        $("#mall-top-menu").addClass("current-item");
}( jQuery ));
